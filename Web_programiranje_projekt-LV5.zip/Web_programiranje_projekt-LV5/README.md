# Web_programiranje_projekt
Vesele note(Online Music Shop)

Vesele note je web aplikacija koja predstavlja online trgovinu glazbenom opremom koja je namijenjena glazbenicima svih uzrasta. Web aplikacija sadržavat će Homepage, navigacijsku listu na kojoj se nalaze kategorije proizvoda. Pristupajući svakom elementu navigacijske liste odlazi se na novu stranicu na kojoj su u listi ponuđeni proizvodi te kategorije. Jedan element navigacijske liste bit će tzv. košarica koja će također biti nova stranica i na njoj će se nalaziti svi proizvodi koji su odabrani za kupnju. Na svakoj stranici s proizvodima bit će omogućeno sortiranje proizvoda po određenim kriterijima. Stranica će također imati univerzalni pretraživač. Klikom na pojedini proizvod otvorit će stranicu s detaljima o istom.

Tehnologije koje će se koristiti pri izradi web aplikacije: -Visual Studio Code -HTML -CSS3 -Bootstrap -PHP -Node.js -React.js -SQL server

Članovi tima: Veronika Pavlik, Luka Opačak, Luka Tadić
